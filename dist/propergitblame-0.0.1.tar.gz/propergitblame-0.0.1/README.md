# propergitblame
propergitblame CLI
